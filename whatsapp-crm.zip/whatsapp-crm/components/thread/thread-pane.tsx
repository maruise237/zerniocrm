'use client';

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, Loader2, MessageSquare, Phone } from 'lucide-react';
import { toast } from 'sonner';
import { CallDialpadDialog } from '@/components/call-dialpad-dialog';
import { Composer } from '@/components/composer/composer';
import { BlockMenu } from '@/components/thread/block-menu';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { useConversationMessages } from '@/hooks/useConversationMessages';
import { apiFetch, ApiError } from '@/lib/api-client';
import { toggleReaction } from '@/lib/reactions';
import { searchMessageIds } from '@/lib/search';
import { countryCodeFromE164, isBicBlocked } from '@/lib/whatsapp/calling';
import { cn } from '@/lib/utils';
import type { Account, Conversation, Message, Selection } from '@/lib/types';
import { MessageList, type MessageListApi } from './message-list';
import { ThreadHeader } from './thread-header';
import { ThreadSearch } from './thread-search';

export interface ThreadPaneProps {
  selected: Selection | null;
  conversation: Conversation | null;
  account: Account | null;
  onBack: () => void;
  /** Optimistic sidebar bump after a send; forwarded to the composer. */
  patchConversation?: (id: string, patch: Partial<Conversation>) => void;
}

const HIGHLIGHT_MS = 2_000;

function errorToast(err: unknown, fallback: string) {
  toast.error(err instanceof ApiError ? err.message : fallback);
}

export function ThreadPane({
  selected,
  conversation,
  account,
  onBack,
  patchConversation,
}: ThreadPaneProps) {
  const threadKey = selected ? `${selected.accountId}:${selected.conversationId}` : 'none';

  const {
    messages,
    isLoading,
    hasMore,
    loadOlder,
    loadingOlder,
    addOptimistic,
    removeOptimistic,
    patchMessage,
    clearPatch,
    refreshHead,
    resetThread,
  } = useConversationMessages({
    conversationId: selected?.conversationId ?? null,
    accountId: selected?.accountId ?? null,
  });

  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [highlightedMessageId, setHighlightedMessageId] = useState<string | null>(null);
  const [editing, setEditing] = useState<Message | null>(null);
  const [editText, setEditText] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);
  const [callOpen, setCallOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  // Active match tracked by ID, not index: when loadOlder prepends new
  // matches, the same message stays active while its index shifts.
  const [activeMatchId, setActiveMatchId] = useState<string | null>(null);

  // Reset all thread-local state when the selected conversation changes.
  // useLayoutEffect so stale older/pending pages from the previous thread are
  // cleared before paint (the head query key already switched).
  useLayoutEffect(() => {
    resetThread();
    setReplyingTo(null);
    setHighlightedMessageId(null);
    setEditing(null);
    setCallOpen(false);
    setSearchOpen(false);
    setSearchQuery('');
    setActiveMatchId(null);
  }, [threadKey, resetThread]);

  const highlightTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const highlightMessage = useCallback((id: string) => {
    setHighlightedMessageId(id);
    if (highlightTimerRef.current) clearTimeout(highlightTimerRef.current);
    highlightTimerRef.current = setTimeout(() => setHighlightedMessageId(null), HIGHLIGHT_MS);
  }, []);
  useEffect(
    () => () => {
      if (highlightTimerRef.current) clearTimeout(highlightTimerRef.current);
    },
    [],
  );

  // Fast lookup for rendering a reply's quoted block.
  const messageById = useMemo(() => {
    const map = new Map<string, Message>();
    for (const m of messages) map.set(m.id, m);
    return map;
  }, [messages]);

  // --- In-thread search ---
  // The message list registers its imperative bits (scroll-to-message with the
  // quote-click highlight, position-preserving load-older) so search reuses
  // those paths instead of duplicating them.
  const listApiRef = useRef<MessageListApi | null>(null);
  const registerListApi = useCallback((api: MessageListApi) => {
    listApiRef.current = api;
  }, []);

  const matchIds = useMemo(
    () => (searchOpen ? searchMessageIds({ messages, query: searchQuery }) : []),
    [searchOpen, messages, searchQuery],
  );
  const activeMatchIndex = activeMatchId === null ? -1 : matchIds.indexOf(activeMatchId);

  const goToMatch = useCallback((id: string) => {
    setActiveMatchId(id);
    listApiRef.current?.scrollToMessage(id);
  }, []);

  // Keep the active match valid as matches recompute (typing, polls,
  // load-older). When it's stale or unset, snap to the newest match; an
  // unchanged id is left alone so prepended pages don't move the cursor.
  useEffect(() => {
    if (!searchOpen) return;
    if (matchIds.length === 0) {
      setActiveMatchId(null);
      return;
    }
    if (activeMatchId !== null && matchIds.includes(activeMatchId)) return;
    goToMatch(matchIds[matchIds.length - 1]);
  }, [searchOpen, matchIds, activeMatchId, goToMatch]);

  // "Next" walks back in time from the newest match (chat-search convention),
  // "previous" walks forward; both wrap around.
  const goToNextMatch = useCallback(() => {
    if (matchIds.length === 0) return;
    const i = activeMatchId === null ? matchIds.length : matchIds.indexOf(activeMatchId);
    goToMatch(matchIds[i <= 0 ? matchIds.length - 1 : i - 1]);
  }, [matchIds, activeMatchId, goToMatch]);

  const goToPrevMatch = useCallback(() => {
    if (matchIds.length === 0) return;
    const i = activeMatchId === null ? -1 : matchIds.indexOf(activeMatchId);
    goToMatch(matchIds[i === -1 || i >= matchIds.length - 1 ? 0 : i + 1]);
  }, [matchIds, activeMatchId, goToMatch]);

  const closeSearch = useCallback(() => {
    setSearchOpen(false);
    setSearchQuery('');
    setActiveMatchId(null);
  }, []);

  const toggleSearch = useCallback(() => {
    if (searchOpen) closeSearch();
    else setSearchOpen(true);
  }, [searchOpen, closeSearch]);

  // Optimistic reaction toggle, reconciled by the head poll (the hook drops
  // the patch once a fresh head includes this message id).
  const handleReact = useCallback(
    async (msg: Message, emoji: string) => {
      if (!selected) return;
      const { next, removed } = toggleReaction({ reactions: msg.reactions, emoji });
      patchMessage(msg.id, { reactions: next });
      const base = `/api/conversations/${encodeURIComponent(selected.conversationId)}/messages/${encodeURIComponent(msg.id)}/reactions`;
      try {
        if (removed) {
          await apiFetch(`${base}?accountId=${encodeURIComponent(selected.accountId)}`, {
            method: 'DELETE',
          });
        } else {
          await apiFetch(base, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ accountId: selected.accountId, emoji }),
          });
        }
      } catch (err) {
        clearPatch(msg.id);
        errorToast(err, 'Failed to react');
      }
    },
    [selected, patchMessage, clearPatch],
  );

  const handleReply = useCallback((msg: Message) => setReplyingTo(msg), []);

  const handleEdit = useCallback((msg: Message) => {
    setEditing(msg);
    setEditText(msg.message);
  }, []);

  const saveEdit = async () => {
    if (!selected || !editing || savingEdit) return;
    const text = editText.trim();
    if (!text) return;
    setSavingEdit(true);
    try {
      await apiFetch(
        `/api/conversations/${encodeURIComponent(selected.conversationId)}/messages/${encodeURIComponent(editing.id)}`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ accountId: selected.accountId, text }),
        },
      );
      setEditing(null);
      await refreshHead();
      toast.success('Message updated');
    } catch (err) {
      errorToast(err, 'Failed to edit message');
    } finally {
      setSavingEdit(false);
    }
  };

  const handleDelete = useCallback(
    async (msg: Message) => {
      if (!selected) return;
      if (!confirm('Delete this message?')) return;
      try {
        await apiFetch(
          `/api/conversations/${encodeURIComponent(selected.conversationId)}/messages/${encodeURIComponent(msg.id)}?accountId=${encodeURIComponent(selected.accountId)}`,
          { method: 'DELETE' },
        );
        await refreshHead();
      } catch (err) {
        errorToast(err, 'Failed to delete message');
      }
    },
    [selected, refreshHead],
  );

  if (!selected || !conversation) {
    return (
      <main
        className={cn(
          'relative h-full flex-1 flex-col items-center justify-center gap-3 bg-[var(--chat-canvas)]',
          // Without a selection the list owns the mobile viewport; with a
          // selection but no resolved conversation yet, stay visible.
          selected ? 'flex' : 'hidden md:flex',
        )}
      >
        {selected ? (
          <>
            {/* Refresh-on-mobile lands here with the list hidden: the back
                button keeps it from being a dead end while the list resolves
                the URL selection. */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2.5 left-2 md:hidden"
              onClick={onBack}
              aria-label="Back to conversations"
            >
              <ArrowLeft className="size-4" />
            </Button>
            <Loader2 className="size-6 animate-spin text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground">Loading conversation</p>
          </>
        ) : (
          <>
            <MessageSquare className="size-8 text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground">Select a conversation</p>
          </>
        )}
      </main>
    );
  }

  // WhatsApp-only header actions: block/unblock menu, plus the outbound
  // calling dial pad when the feature flag is on and the BUSINESS number's
  // country supports business-initiated calling (Meta blocks US/CA/EG/VN/NG;
  // the business number is the WhatsApp account's username digits).
  const isWhatsAppThread = conversation.platform === 'whatsapp' && !!conversation.participantId;
  const canCall =
    process.env.NEXT_PUBLIC_WHATSAPP_CALLING_ENABLED === 'true' &&
    isWhatsAppThread &&
    !isBicBlocked(countryCodeFromE164(account?.username ?? ''));

  return (
    <main className="flex h-full min-w-0 flex-1 flex-col bg-[var(--chat-canvas)]">
      <ThreadHeader
        conversation={conversation}
        onBack={onBack}
        onToggleSearch={toggleSearch}
        actionsSlot={
          isWhatsAppThread ? (
            <>
              {canCall && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-muted-foreground"
                  onClick={() => setCallOpen(true)}
                  title="Call this contact on WhatsApp"
                  aria-label="Call this contact on WhatsApp"
                >
                  <Phone className="size-4" />
                </Button>
              )}
              <BlockMenu conversation={conversation} />
            </>
          ) : undefined
        }
      />
      {searchOpen && (
        <ThreadSearch
          query={searchQuery}
          onQueryChange={setSearchQuery}
          matchCount={matchIds.length}
          activePosition={activeMatchIndex === -1 ? null : matchIds.length - activeMatchIndex}
          onNext={goToNextMatch}
          onPrev={goToPrevMatch}
          onClose={closeSearch}
          hasMore={hasMore}
          loadingOlder={loadingOlder}
          onLoadOlder={() => void listApiRef.current?.loadOlder()}
        />
      )}
      <MessageList
        threadKey={threadKey}
        conversation={conversation}
        messages={messages}
        isLoading={isLoading}
        hasMore={hasMore}
        loadingOlder={loadingOlder}
        loadOlder={loadOlder}
        messageById={messageById}
        highlightedMessageId={highlightedMessageId}
        onHighlight={highlightMessage}
        registerApi={registerListApi}
        bubbleHandlers={{
          onReact: handleReact,
          onReply: handleReply,
          onEdit: handleEdit,
          onDelete: handleDelete,
        }}
      />
      {/* Keyed by thread so drafts/sending state never bleed across threads. */}
      <Composer
        key={threadKey}
        conversation={conversation}
        account={account}
        replyingTo={replyingTo}
        onCancelReply={() => setReplyingTo(null)}
        addOptimistic={addOptimistic}
        removeOptimistic={removeOptimistic}
        refreshHead={refreshHead}
        patchConversation={patchConversation}
        messages={messages}
        messagesLoading={isLoading}
      />

      {/* WhatsApp Business Calling dial pad; mounted per open so its polling
          and state reset cleanly on close. */}
      {callOpen && canCall && conversation.participantId && (
        <CallDialpadDialog
          accountId={conversation.accountId}
          initialTo={`+${conversation.participantId.replace(/^\+/, '')}`}
          onClose={() => setCallOpen(false)}
        />
      )}

      {/* Telegram message edit */}
      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit message</DialogTitle>
          </DialogHeader>
          <Textarea
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            rows={4}
            aria-label="Edited message text"
          />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditing(null)} disabled={savingEdit}>
              Cancel
            </Button>
            <Button onClick={() => void saveEdit()} disabled={savingEdit || !editText.trim()}>
              {savingEdit && <Loader2 className="size-4 animate-spin" />}
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  );
}
